<?php

namespace Qcloud\Cos\Exception;

class CurlException extends CosException {}
