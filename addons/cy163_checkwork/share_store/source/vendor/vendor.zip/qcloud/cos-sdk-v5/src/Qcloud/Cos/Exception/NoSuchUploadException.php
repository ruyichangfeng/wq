<?php

namespace Qcloud\Cos\Exception;

/**
 * The specified multipart upload does not exist.
 */
class NoSuchUploadException extends CosException {}
